<?php

namespace App\Http\Controllers\Crawler;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class CrawlerTruyenYYController extends Controller
{
    public $link = '';
}
